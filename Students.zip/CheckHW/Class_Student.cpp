﻿
#include "Class_Student.h"
//---------------------------------------------------------------КЛАСС STUDENT-----------------------------------------
Student::Student()
{
	id = 0;
	age = 16;
	name = "studentname";
	st_class = "none";
	std::cout << "\nNew student is done";
}
Student::~Student()											//деструктор
{
	//std::cout << std::endl << name << " is terminated";
}
void Student::redact()										//редоктор студента
{
	std::cout << "\nName: ";
	std::cin.ignore(32767, '\n');
	std::getline(std::cin, name);
	std::cout << "\nAge: ";
	std::cin >> age;
	std::cout << "\nID: ";
	std::cin >> id;
	std::cout << "\nClass: ";
	std::cin >> st_class;
}
void Student::print()
{
	std::cout << std::endl << name << ", " << age
		<< " years old, id is: " << id
		<< " and in " << st_class << " class";
}
//--------------------------------------------------------------КОНЕЦ КЛАССА STUDENT-----------------------------------------------------

void print_vec(std::vector <Student> &vec)
{
	for (int i = 0; i < vec.size(); i++)
	{
		vec.at(i).print();
	}
}

void add_student(std::vector <Student> &vec, int amount)
{
	Student buff_student;
	for (int i = 0; i < amount; i++)
	{
		buff_student.redact();
		vec.push_back(buff_student);
	}
}

void get_a_num(int& num, std::string message)
{
	std::cout << std::endl << message;
	std::cin >> num;
}